import numpy as np
import pandas as pd
import pickle
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

"""
Plot Euler-VI, Observe then plan, DRQN, ACNO-POMCP, baseline POMDP (with true model parameters)
"""
def main():
    colors = sns.color_palette("tab10")

    # mdp
    mdps = []
    for i in range(3):
        f = pickle.load(open('euler_vi_explore_{}.obj'.format(i), 'rb'))
        discounts = np.array([0.7 ** j for j in range(5)])
        cum_dis = [0]
        for j in range(5):
            cum_dis.append(discounts[j] + cum_dis[-1])
        cum_dis = cum_dis[1:]
        obs_rew = []
        for j in range(1000):
            obs_rew.append(f['rew'][j] - 0.1 * cum_dis[ (f['steps'][j])-1])
        f = np.load('euler_vi_plan_{}.npy'.format(i))
        for j in range(1000):
            obs_rew.append(f[j])

        df = pd.DataFrame(obs_rew)
        mdps.append(np.array(df.rolling(50, min_periods=1).mean()[:]))

    # pomdp
    pomcps = []
    for i in range(3):
        f = pickle.load(open('otp_observe_{}.obj'.format(i), 'rb'))
        discounts = np.array([0.7 ** j for j in range(5)])
        cum_dis = [0]
        for j in range(5):
            cum_dis.append(discounts[j] + cum_dis[-1])
        cum_dis = cum_dis[1:]
        obs_rew = []

        # this was trick added since euler code for m' exploration didn't consider the discount factor
        # can be replaced by lines 17~22 if the logging includes the discounted reward but no observation cost
        for j in range(1000):
            rew = f['rew'][j]
            if f['steps'][j] == 5:
                if rew == 1.25:
                    rew = 0.693275
                if rew == 2:
                    rew = 0.87335
                if rew == 1:
                    rew = 0.63325

            if f['steps'][j] == 4:
                if rew == 1.0:
                    assert(False)
                    # rew = 0.633275
                if rew == 1.75:
                    rew = 0.8905
                if rew == 0.75:
                    rew = 0.5475

            if f['steps'][i] == 3:
                if rew == 0.5:
                    rew = 0.425
                elif rew == 1.5:
                    rew = 0.915
                else:
                    assert(False)

            if f['steps'][i] == 2:
                if rew == 1.25:
                    rew = 0.95
                elif rew == 0.25:
                    rew = 0.25
                else:
                    assert(False)

            if f['steps'][i] == 1:
                rew = 0
            obs_rew.append(rew - 0.1 * cum_dis[ (f['steps'][j]) -1])

        """ below if considering the true observation cost """
        f = np.load('otp_plan_{}.npy'.format(i))
        for j in range(1000):
            obs_rew.append(f[j])
        df = pd.DataFrame(obs_rew)
        pomcps.append(np.array(df.rolling(50, min_periods=1).mean())[:])

    # DRQN
    drqns = []
    for i in range(3):
        f = np.load('drqn_{}.npy'.format(i))
        obs_rew = f[:2000]
        df = pd.DataFrame(obs_rew)
        drqns.append(np.array(df.rolling(50, min_periods=1).mean()[:]))

    # pomdp-rl
    pomdp_rls = []
    for i in range(3):
        f = np.load('acno_pomcp_{}.npy'.format(i))
        # print(len(f))
        obs_rew = f[:2000]
        df = pd.DataFrame(obs_rew)
        pomdp_rls.append(np.array(df.rolling(50, min_periods=1).mean()[:]))

    planning = []
    for i in range(3):
        f = np.load('plan_{}.npy'.format(i))
        f = f[-1000:]
        planning.append(f)

    plt.axhline(np.mean(planning), color='gray')

    pomcps = np.array(pomcps)[:,:,0]
    plt.plot(np.mean(pomcps, 0), label='Observe-then-Plan', color=colors[0])
    plt.fill_between(np.arange(2000), np.mean(pomcps, 0) - np.std(pomcps, 0) /np.sqrt(3), np.mean(pomcps, 0) + np.std(pomcps, 0) / np.sqrt(3), color=colors[0], alpha=.3)

    pomdp_rls = np.array(pomdp_rls)[:,:,0]
    plt.plot(np.mean(pomdp_rls, 0), label='ACNO-POMCP', color=colors[3])
    plt.fill_between(np.arange(2000), np.mean(pomdp_rls, 0) - np.std(pomdp_rls, 0) /np.sqrt(3), np.mean(pomdp_rls, 0) + np.std(pomdp_rls, 0) / np.sqrt(3), color=colors[3], alpha=.3)

    drqns = np.array(drqns)[:,:,0]
    plt.plot(np.mean(drqns, 0), label='DRQN', color=colors[1])
    plt.fill_between(np.arange(2000), np.mean(drqns, 0) - np.std(drqns, 0) /np.sqrt(3), np.mean(drqns, 0) + np.std(drqns, 0) / np.sqrt(3), color=colors[1], alpha=.3)

    mdps = np.array(mdps)[:,:,0]

    plt.plot(np.mean(mdps, 0), label='EULER-VI (always observing)', color=colors[2])
    plt.fill_between(np.arange(2000), np.mean(mdps, 0) - np.std(mdps, 0) /np.sqrt(3), np.mean(mdps, 0) + np.std(mdps, 0) / np.sqrt(3), color=colors[2], alpha=.3)


    plt.axvline(1000, linestyle='--',color='black')
    plt.legend()
    plt.title('Learning curves on sepsis with observation cost of -0.1')
    plt.xlabel('Train Episode (Rolling averaging window of 50 eps)')
    plt.ylabel('Discounted returns')
    plt.tight_layout()
    plt.savefig('sepsis.png')

if __name__ == "__main__":
    main()
